# Vialute

## 概要

Vialute Webサイト

## インストール

1. リポジトリをクローンする。

```
git clone git@github.com:yU-kiki/vialute.git
```

2. 必要なパッケージをインストールする。

```
npm install
```

3. アプリケーションを起動する。

```
npm run dev
```
## タスク管理

[タスク管理]()

## UIデザイン

[Figma]()

## ディレクトリ設計

### (routes)

アプリケーションのルーティングに関連するコンポーネントを格納する。

- layout.tsx: 全体のレイアウトを定義
- page.tsx: ページコンポーネントを定義

### _common

アプリケーション全体で使用される共通のスタイルやユーティリティを格納する。

- styles/globals.css: グローバルスタイルを定義

### _components

アプリケーション全体で共通して使用されるUIコンポーネントを格納する。

- elements: 小さな再利用可能なUI要素
- layouts: レイアウトコンポーネント（Header、Footer）

### _features

アプリケーションの各機能に関連するコードを格納する。<br>
各機能ごとにフォルダを作成し、その中に関連するコンポーネントやロジックを配置する。

### _hooks

共通的に使われる複数のリポジトリをまたぐ実装、ロジックなどを格納する。

### _services

API呼び出しやその他のサービスロジックを格納する。

### _types

TypeScriptの型定義を格納する。
