export const entryContentState = {
  roleName: "",
  name: "",
  ruby: "",
  tel: "",
  mail: "",
  reason: "",
  portfolio: "",
};
