import clsx from "clsx";
import Link from "next/link";
import { usePathname } from "next/navigation";
import React, { useState, useEffect } from "react";
import { MenuHeader } from "@/_components/layouts/MenuHeader";
import { MenuFooter } from "@/_components/layouts/MenuFooter";
import { InteractiveText } from "@/_components/animations/InteractiveText";

interface FullScreenMenuProps {
  onClose: () => void;
}

export const FullScreenMenu: React.FC<FullScreenMenuProps> = ({ onClose }) => {
  const [isProjectsHovered, setIsProjectsHovered] = useState(false);
  const pathname = usePathname(); 

  const handleLinkClick = () => {
    onClose();
  };

  const handleOtherHover = () => {
    setIsProjectsHovered(false);
  };

  useEffect(() => {
    document.body.classList.add("overflow-hidden");
    return () => {
      document.body.classList.remove("overflow-hidden");
    };
  }, []);

  return (
    <div
      className={clsx(
        "fixed",
        "top-0",
        "left-0",
        "w-[100vw]",
        "h-full",
        "sm:h-[100vh]",
        "bg-white",
        pathname === "/" ? "opacity-90" : "opacity-100",
        "z-50",
        "overflow-y-auto"
      )}
    >
      <MenuHeader />
      <div
        className={clsx(
          "flex",
          "w-[100vw]",
          "h-auto",
          "sm:h-[100vh]",
          "mt-[64px]",
          "sm:mt-0",
          "px-[40px]",
          "sm:pl-[120px]",
          "sm:pr-[80px]"
        )}
      >
        <p
          className={clsx(
            "hidden",
            "sm:inline",
            "mt-[calc(50vh-160px)]",
            "text-[128px]",
            "font-gillSans"
          )}
        >
          Menu
        </p>
        <div
          className={clsx(
            "flex",
            "sm:justify-center",
            "flex-col",
            "gap-y-[48px]",
            "sm:ml-[160px]",
            "text-[48px]",
            "font-gillSans",
            "text-gray"
          )}
        >
          <InteractiveText>
            <Link
              href="/"
              className={clsx("hover:text-main-black")}
              onClick={handleLinkClick}
              onMouseEnter={handleOtherHover}
            >
              Home
            </Link>
          </InteractiveText>
          <InteractiveText>
            <p
              className={clsx("hover:text-main-black", "cursor-pointer")}
              onMouseEnter={handleOtherHover}
            >
              About
            </p>
          </InteractiveText>
          <div
            className={clsx(
              "sm:relative",
              "hover:text-main-black",
              "cursor-pointer"
            )}
            onMouseEnter={() => setIsProjectsHovered(true)}
          >
            <InteractiveText>
              <Link
                href="/projects"
                className={clsx("hover:text-main-black", "cursor-pointer")}
                onClick={handleLinkClick}
              >
                Projects
              </Link>
            </InteractiveText>
            {/* {isProjectsHovered && ( */}
            <div
              className={clsx(
                "block",
                "sm:absolute",
                isProjectsHovered ? "block" : "hidden",
                "sm:left-full",
                "sm:top-0",
                "flex",
                "justify-center",
                "flex-col",
                "sm:w-[360px]",
                "mt-[32px]",
                "sm:my-0",
                "sm:ml-[80px]",
                "text-[20px]",
                "font-sans",
                "text-gray"
              )}
            >
              <p className={clsx("p-[32px]", "border-y")}>
                <p className={clsx("hover:text-main-black")}>Virtual Human</p>
              </p>
              <p className={clsx("p-[32px]")}>
                <p className={clsx("hover:text-main-black")}>
                  Virtual Human Live Streaming
                </p>
              </p>
              <p className={clsx("p-[32px]", "border-y")}>
                <p className={clsx("hover:text-main-black")}>
                  Creative Consulting
                </p>
              </p>
            </div>
            {/* )} */}
          </div>
          <InteractiveText>
            <p
              className={clsx("hover:text-main-black", "cursor-pointer")}
              onMouseEnter={handleOtherHover}
            >
              News
            </p>
          </InteractiveText>
          <InteractiveText>
            <Link
              href="/careers"
              className={clsx("hidden", "sm:inline", "hover:text-main-black")}
              onClick={handleLinkClick}
              onMouseEnter={handleOtherHover}
            >
              Careers
            </Link>
          </InteractiveText>
        </div>
      </div>
      <MenuFooter onClose={handleLinkClick} />
    </div>
  );
};
