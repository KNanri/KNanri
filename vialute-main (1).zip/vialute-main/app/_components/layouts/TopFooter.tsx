"use client";

import { MenuFooter } from "@/_components/layouts/MenuFooter";
import { useMenu } from "@/_hooks/useMenu";
import clsx from "clsx";

export const TopFooter = () => {
  const { isOpen } = useMenu();

  if (isOpen) {
    return <MenuFooter />;
  }

  return (
    <footer
      className={clsx(
        "fixed",
        "bottom-[48px]",
        "left-[32px]",
        "sm:left-[80px]",
        "z-[10]",
        "leading-[2.5]",
        "font-[300]",
        "text-[14px]",
        "text-white"
      )}
    >
      <p>
        We expand our human potential and create new value.
        <br />ⓒ &Jam Inc. All rights reserved.
      </p>
    </footer>
  );
};
