"use client";

import clsx from "clsx";
import Link from "next/link";
import { HeaderIcon } from "@/_components/elements/HeaderIcon";
import { MenuButton } from "@/_components/elements/MenuButton";
import { CharChangeAnimation } from "@/_components/animations/CharChangeAnimation";
import { FullScreenMenu } from "@/_components/layouts/FullScreenMenu";
import { useMenu } from "@/_hooks/useMenu";

type HeaderProps = {
  textColor: string;
  logoSrc: string;
};

export const Header = ({ textColor, logoSrc }: HeaderProps) => {
  const { isOpen, openMenu, closeMenu } = useMenu();

  if (isOpen) {
    return <FullScreenMenu onClose={closeMenu} />;
  }

  return (
    <header
      className={clsx(
        "flex",
        "justify-between",
        "items-center",
        "fixed",
        "top-[16px]",
        "sm:top-[40px]",
        "z-[10]",
        "w-full",
        "px-[24px]",
        "sm:px-[80px]"
      )}
    >
      <HeaderIcon logoSrc={logoSrc} />
      <div
        className={clsx(
          "flex",
          "gap-x-[80px]",
          "h-[100%]",
          "font-[400]",
          "text-[16px]",
          textColor
        )}
      >
        <p className={clsx("hidden", "sm:inline")}>
          <CharChangeAnimation text="ABOUT" duration={1000} />
        </p>
        <div className={clsx("w-[86px]")}>
          <Link href="/projects" className={clsx("hidden", "sm:inline")}>
            <CharChangeAnimation text="PROJECTS" duration={1000} />
          </Link>
        </div>
        <MenuButton isOpen={isOpen} onClick={openMenu} />
      </div>
    </header>
  );
};
