"use client";

import clsx from "clsx";
import Link from "next/link";
import Image from "next/image";
import { useState } from "react";
import { InteractiveText } from "@/_components/animations/InteractiveText";

export const Footer = () => {
  const [isHovered, setIsHovered] = useState(false);
  const [animate, setAnimate] = useState(false);

  const handleMouseEnter = () => {
    setIsHovered(true);
    if (!animate) {
      setAnimate(true);
    }
  };

  const handleAnimationEnd = () => {
    setAnimate(false);
  };

  const handleMouseLeave = () => {
    setIsHovered(false);
  };

  return (
    <footer
      className={clsx(
        "bg-[url('/patterns/footer_pattern.svg')]",
        "bg-[position:calc((100vw-1512px)/2-30px)_calc(816px-669px)]",
        "flex",
        "flex-col",
        "justify-between",
        "sm:h-[816px]",
        "pt-[30px]",
        "sm:pt-[100px]",
        "px-[20px]",
        "sm:px-[80px]",
        "2xl:px-[160px]",
        "bg-black"
      )}
    >
      <div className={clsx("flex", "flex-col", "sm:flex-row")}>
        <div className={clsx("relative", "sm:w-[450px]", "mr-[40px]")}>
          <Link
            href="/contact"
            className={clsx(
              "absolute",
              "top-[143px]",
              "sm:top-[294px]",
              "left-[60px]",
              "sm:left-[137px]",
              "flex",
              "justify-center",
              "w-[80px]",
              "sm:w-[125px]",
              "h-[80px]",
              "sm:h-[125px]",
              "border-[2px]",
              "border-white",
              "rounded-full",
              "bg-white/40",
              animate ? "animate-poyoyon" : "",
              isHovered ? "text-white" : "text-purple"
            )}
            onMouseEnter={handleMouseEnter}
            onMouseLeave={handleMouseLeave}
            onAnimationEnd={handleAnimationEnd}
          >
            <Image
              src="/icons/arrow.svg"
              alt="矢印"
              width={25}
              height={50}
              priority
            />
          </Link>
          <Image
            className={clsx("w-[243px]", "sm:w-[451px]")}
            src="/logo/andjam_logo_footer.png"
            alt="フッターロゴ"
            width={451}
            height={229}
            priority
          />
          <p
            className={clsx(
              "font-[700]",
              "text-[43px]",
              "sm:text-[82px]",
              "font-gillSans",
              isHovered ? "text-white" : "text-purple"
            )}
          >
            CONTACT
            <br />
            US
          </p>
        </div>
        <div
          className={clsx(
            "flex",
            "flex-col",
            "sm:flex-row",
            "sm:mt-[64px]",
            "mt-0",
            "font-[300]",
            "text-white"
          )}
        >
          <div className={clsx("mt-[64px]", "sm:mt-0", "sm:mr-[40px]")}>
            <p className={clsx("font-[600]", "text-[20px]")}>NAVIGATION</p>
            <div
              className={clsx(
                "flex",
                "flex-col",
                "gap-y-[24px]",
                "mt-[40px]",
                "sm:mt-[50px]"
              )}
            >
              <InteractiveText>
                <Link href="/">Home</Link>
              </InteractiveText>
              <InteractiveText>
                <p>About</p>
              </InteractiveText>
              <div className={clsx("flex")}>
                <InteractiveText>
                  <Link href="/projects">Projects</Link>
                </InteractiveText>
                <div className={clsx("flex", "flex-col", "gap-y-[24px]")}>
                  <div className={clsx("flex")}>
                    <span
                      className={clsx(
                        "bar-line",
                        "w-[36px]",
                        "mt-[13px]",
                        "mx-[40px]"
                      )}
                    ></span>
                    <InteractiveText>
                      <p>Virtual Human</p>
                    </InteractiveText>
                  </div>
                  <div className={clsx("flex")}>
                    <span
                      className={clsx(
                        "bar-line",
                        "w-[36px]",
                        "mt-[13px]",
                        "mx-[40px]"
                      )}
                    ></span>
                    <InteractiveText>
                      <p>Virtual Human Live Streaming</p>
                    </InteractiveText>
                  </div>
                  <div className={clsx("flex")}>
                    <span
                      className={clsx(
                        "bar-line",
                        "w-[36px]",
                        "mt-[13px]",
                        "mx-[40px]"
                      )}
                    ></span>
                    <InteractiveText>
                      <p>Creative Consulting</p>
                    </InteractiveText>
                  </div>
                </div>
              </div>
              <InteractiveText>
                <p>News</p>
              </InteractiveText>
              <InteractiveText>
                <Link href="/careers" className={clsx("hidden", "sm:inline")}>
                  Careers
                </Link>
              </InteractiveText>
            </div>
          </div>
          <div className={clsx("mt-[48px]", "sm:mt-0")}>
            <p className={clsx("font-[600]", "text-[20px]")}>FOLLOW US</p>
            <div
              className={clsx(
                "flex",
                "flex-col",
                "gap-x-[64px]",
                "gap-y-[32px]",
                "mt-[40px]",
                "sm:mt-[50px]"
              )}
            >
              {/* <div className={clsx("flex", "gap-x-[64px]")}>
                <InteractiveText>
                  <Link
                    className={clsx("flex")}
                    href="https://www.facebook.com/"
                    rel="noopener noreferrer"
                    target="_blank"
                  >
                    Facebook
                    <Image
                      className={clsx("mt-[2px]", "ml-[8px]")}
                      src="/icons/go_to_link_arrow.svg"
                      alt="リンク遷移の矢印"
                      width={8}
                      height={8}
                    />
                  </Link>
                </InteractiveText>
                <InteractiveText>
                  <Link
                    className={clsx("flex")}
                    href="https://www.instagram.com/"
                    rel="noopener noreferrer"
                    target="_blank"
                  >
                    Instagram
                    <Image
                      className={clsx("mt-[2px]", "ml-[8px]")}
                      src="/icons/go_to_link_arrow.svg"
                      alt="リンク遷移の矢印"
                      width={8}
                      height={8}
                    />
                  </Link>
                </InteractiveText>
              </div>
              <div className={clsx("flex", "gap-x-[64px]")}>
                <InteractiveText>
                  <Link
                    className={clsx("flex")}
                    href="https://x.com"
                    rel="noopener noreferrer"
                    target="_blank"
                  >
                    X
                    <Image
                      className={clsx("mt-[2px]", "ml-[8px]")}
                      src="/icons/go_to_link_arrow.svg"
                      alt="リンク遷移の矢印"
                      width={8}
                      height={8}
                    />
                  </Link>
                </InteractiveText>
                <InteractiveText>
                  <Link
                    className={clsx("flex")}
                    href="https://note.com"
                    rel="noopener noreferrer"
                    target="_blank"
                  >
                    note
                    <Image
                      className={clsx("mt-[2px]", "ml-[8px]")}
                      src="/icons/go_to_link_arrow.svg"
                      alt="リンク遷移の矢印"
                      width={8}
                      height={8}
                    />
                  </Link>
                </InteractiveText>
              </div> */}
              <div className={clsx("flex", "gap-x-[64px]")}>
                <InteractiveText>
                  <p className={clsx("flex")}>
                    Facebook
                    <Image
                      className={clsx("mt-[2px]", "ml-[8px]")}
                      src="/icons/go_to_link_arrow.svg"
                      alt="リンク遷移の矢印"
                      width={8}
                      height={8}
                    />
                  </p>
                </InteractiveText>
                <InteractiveText>
                  <p className={clsx("flex")}>
                    Instagram
                    <Image
                      className={clsx("mt-[2px]", "ml-[8px]")}
                      src="/icons/go_to_link_arrow.svg"
                      alt="リンク遷移の矢印"
                      width={8}
                      height={8}
                    />
                  </p>
                </InteractiveText>
              </div>
              <div className={clsx("flex", "gap-x-[64px]")}>
                <InteractiveText>
                  <p className={clsx("flex")}>
                    X
                    <Image
                      className={clsx("mt-[2px]", "ml-[8px]")}
                      src="/icons/go_to_link_arrow.svg"
                      alt="リンク遷移の矢印"
                      width={8}
                      height={8}
                    />
                  </p>
                </InteractiveText>
                <InteractiveText>
                  <p className={clsx("flex")}>
                    note
                    <Image
                      className={clsx("mt-[2px]", "ml-[8px]")}
                      src="/icons/go_to_link_arrow.svg"
                      alt="リンク遷移の矢印"
                      width={8}
                      height={8}
                    />
                  </p>
                </InteractiveText>
              </div>
            </div>
          </div>
        </div>
      </div>
      <p
        className={clsx(
          "mt-[112px]",
          "sm:mt-[240px]",
          "mb-[32px]",
          "sm:mb-[48px]",
          "text-white",
          "text-center"
        )}
      >
        ⓒ &Jam Inc. All rights reserved.
      </p>
    </footer>
  );
};
