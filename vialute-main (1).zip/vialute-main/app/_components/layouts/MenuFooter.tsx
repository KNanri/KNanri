import clsx from "clsx";
import Link from "next/link";

interface MenuFooterProps {
  onClose?: () => void;
}

export const MenuFooter: React.FC<MenuFooterProps> = ({ onClose }) => {
  return (
    <footer
      className={clsx(
        "flex",
        "flex-col",
        "sm:flex-row",
        "justify-between",
        "sm:fixed",
        "bottom-[64px]",
        "z-[10]",
        "w-full",
        "px-[40px]",
        "sm:px-[80px]",
        "font-[300]",
        "text-[16px]",
        "text-main-black"
      )}
    >
      <div
        className={clsx(
          "flex",
          "flex-col",
          "md:flex-row",
          "gap-x-[80px]",
          "gap-y-[32px]",
          "items-start",
          "mt-[64px]",
          "sm:mt-0",
          "sm:items-center"
        )}
      >
        {/* <Link
          href="https://www.facebook.com/"
          rel="noopener noreferrer"
          target="_blank"
        >
          Facebook
        </Link>
        <Link
          href="https://www.instagram.com/"
          rel="noopener noreferrer"
          target="_blank"
        >
          Instagram
        </Link>
        <Link href="https://x.com" rel="noopener noreferrer" target="_blank">
          X
        </Link>
        <Link href="https://note.com" rel="noopener noreferrer" target="_blank">
          note
        </Link>
        <Link href="/contact" rel="noopener noreferrer" onClick={onClose}>
          Contact
        </Link> */}
        <p>Facebook</p>
        <p>Instagram</p>
        <p>X</p>
        <p>note</p>
        <Link href="/contact" rel="noopener noreferrer" onClick={onClose}>
          Contact
        </Link>
      </div>
      <p className={clsx("mt-[64px]", "mb-[32px]", "sm:my-0", "text-center")}>
        ⓒ &Jam Inc. All rights reserved.
      </p>
    </footer>
  );
};
