import clsx from "clsx";
import React from "react";
import { HeaderIcon } from "@/_components/elements/HeaderIcon";
import { MenuButton } from "@/_components/elements/MenuButton";
import { useMenu } from "@/_hooks/useMenu";

export const MenuHeader = () => {
  const { isOpen, closeMenu } = useMenu();

  return (
    <div
      className={clsx(
        "flex",
        "justify-between",
        "items-center",
        "sm:fixed",
        "top-[16px]",
        "sm:top-[40px]",
        "z-[10]",
        "w-full",
        "mt-[16px]",
        "sm:mt-0",
        "px-[24px]",
        "sm:px-[80px]"
      )}
    >
      <HeaderIcon logoSrc="/logo/andjam_logo_black.png" />
      <MenuButton isOpen={isOpen} onClick={closeMenu} />
    </div>
  );
};
