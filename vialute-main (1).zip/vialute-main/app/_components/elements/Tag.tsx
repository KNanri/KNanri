import clsx from "clsx";

interface TagProps {
  name: string;
  selected: boolean;
  onClick: () => void;
}

export const Tag = ({ name, selected, onClick }: TagProps) => {
  return (
    <p
      className={clsx(
        "mt-[16px]",
        "mr-[20px]",
        "px-[16px]",
        "py-[8px]",
        "border-[0.5px]",
        "border-black",
        "rounded-full",
        "font-[300]",
        "text-[16px]",
        selected ? "text-white" : "text-main-black",
        selected ? "bg-purple" : "",
        "cursor-pointer"
      )}
      onClick={onClick}
    >
      {name}
    </p>
  );
};
