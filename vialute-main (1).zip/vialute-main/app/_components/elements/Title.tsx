import clsx from "clsx";

type TitleProps = {
  enTitle: string;
  jaTitle?: string;
  className?: string;
};

export const Title = ({ enTitle, jaTitle, className }: TitleProps) => {
  return (
    <div className={clsx(className)}>
      <h2 className={clsx("text-[80px]", "font-gillSans")}>
        {enTitle}
      </h2>
      {jaTitle && (
        <p className={clsx("mt-[8px]", "text-[14px]", "text-gray")}>
          {jaTitle}
        </p>
      )}
    </div>
  );
};
