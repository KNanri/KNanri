import clsx from "clsx";
import React from "react";

export type InputProps = {
  name: string;
  jaLabel: string;
  enLabel: string;
  placeholder?: string;
  type?: string;
  value: string;
  onChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
  errorMessage?: string;
  required?: boolean;
};

export const Input = ({
  name,
  jaLabel,
  enLabel,
  placeholder,
  type = "text",
  value,
  onChange,
  errorMessage,
  required = false,
}: InputProps) => (
  <div className={clsx("mt-[32px]")}>
    <label>
      <p className={clsx("text-[14px]", "text-gray")}>{jaLabel}</p>
      <p className={clsx("mt-[4px]", "text-[24px]")}>{enLabel}</p>
    </label>
    <input
      id={name}
      name={name}
      type={type}
      value={value}
      onChange={onChange}
      className={clsx(
        "w-full",
        "mt-[8px]",
        "p-[20px]",
        "border-solid",
        "border-[0.5px]",
        errorMessage ? "border-purple" : "border-main-black",
        "placeholder-light-gray"
      )}
      placeholder={placeholder}
      required={required}
    />
    {errorMessage && (
      <p className={clsx("mt-[8px]", "text-[14px]", "text-purple")}>
        {errorMessage}
      </p>
    )}
  </div>
);
