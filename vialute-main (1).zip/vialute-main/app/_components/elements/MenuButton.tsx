import clsx from "clsx";

type MenuButtonProps = {
  isOpen: boolean;
  onClick: () => void;
};

export const MenuButton = ({ isOpen, onClick }: MenuButtonProps) => {
  return (
    <button
      className={clsx("menuButton", { open: isOpen })}
      onClick={onClick}
      aria-label="メニュー"
    >
      <span className={clsx("bar")}></span>
      <span className={clsx("bar")}></span>
    </button>
  );
};
