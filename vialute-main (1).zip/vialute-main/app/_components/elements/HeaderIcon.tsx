"use client";

import clsx from "clsx";
import Image from "next/image";
import Link from "next/link";

type HeaderIconProps = {
  logoSrc: string;
};

export const HeaderIcon = ({ logoSrc }: HeaderIconProps) => {
  return (
    <Link href="/">
      <Image
        className={clsx(
          "max-w-[100%]",
          "w-[126px]",
          "sm:w-[175px]",
          "h-auto"
        )}
        src={logoSrc}
        alt="&jam ロゴ"
        width={4096}
        height={2304}
        priority
      />
    </Link>
  );
};
