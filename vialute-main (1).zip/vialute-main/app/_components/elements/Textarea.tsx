import clsx from "clsx";
import React from "react";

export type TextareaProps = {
  name: string;
  jaLabel: string;
  enLabel: string;
  placeholder?: string;
  value: string;
  onChange: (e: React.ChangeEvent<HTMLTextAreaElement>) => void;
  errorMessage?: string;
  required?: boolean;
};

export const Textarea = ({
  name,
  jaLabel,
  enLabel,
  placeholder,
  value,
  onChange,
  errorMessage,
  required = false,
}: TextareaProps) => (
  <div className={clsx("mt-[32px]")}>
    <label>
      <p className={clsx("text-[14px]", "text-gray")}>{jaLabel}</p>
      <p className={clsx("mt-[4px]", "text-[24px]")}>{enLabel}</p>
    </label>
    <textarea
      id={name}
      name={name}
      value={value}
      onChange={onChange}
      className={clsx(
        "w-full",
        "h-[200px]",
        "mt-[8px]",
        "p-[20px]",
        "border-solid",
        "border-[0.5px]",
        errorMessage ? "border-purple" : "border-main-black",
        "placeholder-light-gray"
      )}
      placeholder={placeholder}
      required={required}
    />
    {errorMessage && (
      <p className={clsx("mt-[8px]", "text-[14px]", "text-purple")}>
        {errorMessage}
      </p>
    )}
  </div>
);
