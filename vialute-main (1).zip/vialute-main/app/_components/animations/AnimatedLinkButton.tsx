import Link from "next/link";
import clsx from "clsx";
import React from "react";

type AnimatedLinkButtonProps = {
  href: string;
  text: string;
};

export const AnimatedLinkButton = ({ href, text }: AnimatedLinkButtonProps) => {
  return (
    <>
      <Link href={href} className={clsx("color_change_btn")}>
        {text}
      </Link>
    </>
  );
};
