"use client";

import React, { useEffect, useState, useRef } from "react";

interface CharChangeAnimationProps {
  text: string;
  duration?: number;
  characters?: string;
}

export const CharChangeAnimation: React.FC<CharChangeAnimationProps> = ({
  text,
  duration = 2000,
  characters = "0123456789!#$%&'()*+,-./",
}) => {
  const [displayedText, setDisplayedText] = useState<string[]>([]);
  const isAnimating = useRef<boolean>(false);

  const startAnimation = () => {
    if (isAnimating.current) return;

    isAnimating.current = true;

    const targetText = text.split("");
    const initialText = targetText.map(() => "");
    setDisplayedText(initialText);

    const interval = 50;
    const totalSteps = duration / interval;
    let currentStep = 0;

    const stepInterval = setInterval(() => {
      setDisplayedText((prev) =>
        prev.map((char, index) => {
          if (char === targetText[index]) return char;
          if (currentStep >= totalSteps) return targetText[index];
          return characters.charAt(
            Math.floor(Math.random() * characters.length)
          );
        })
      );

      currentStep++;

      if (currentStep >= totalSteps) {
        clearInterval(stepInterval);
        setDisplayedText(targetText);
        isAnimating.current = false;
      }
    }, interval);
  };

  useEffect(() => {
    startAnimation();

    return () => {
    };
  }, [text, duration, characters]);

  const handleMouseEnter = () => {
    startAnimation();
  };

  return (
    <span onMouseEnter={handleMouseEnter} className="cursor-pointer">
      {displayedText.join("")}
    </span>
  );
};
