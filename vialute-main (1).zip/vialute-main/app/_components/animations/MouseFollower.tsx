"use client";

import clsx from "clsx";
import React, { useEffect, useState } from "react";

export const MouseFollower: React.FC = () => {
  const [position, setPosition] = useState({ x: -100, y: -100 });

  useEffect(() => {
    const handleMouseMove = (event: MouseEvent) => {
      setPosition({ x: event.clientX, y: event.clientY });
    };

    window.addEventListener("mousemove", handleMouseMove);

    return () => {
      window.removeEventListener("mousemove", handleMouseMove);
    };
  }, []);

  return (
    <div
      className={clsx(
        "fixed",
        "pointer-events-none",
        "transition-transform",
        "duration-150",
        "ease-out"
      )}
      style={{
        transform: `translate(${position.x - 15}px, ${position.y - 15}px)`,
      }}
    >
      <div
        className={clsx(
          "w-[30px]",
          "h-[30px]",
          "bg-white",
          "rounded-full",
          "opacity-50"
        )}
      ></div>
    </div>
  );
};
