"use client";

import React, { useRef, useState, useEffect, ReactNode } from "react";
import clsx from "clsx";

interface InteractiveTextProps {
  children: ReactNode;
  className?: string;
}

export const InteractiveText: React.FC<InteractiveTextProps> = ({
  children,
  className,
}) => {
  const textRef = useRef<HTMLSpanElement>(null);
  const [transform, setTransform] = useState({ x: 0, y: 0 });
  const [isHover, setIsHover] = useState(false);

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!textRef.current) return;
    const rect = textRef.current.getBoundingClientRect();
    const x = e.clientX - rect.left - rect.width / 2;
    const y = e.clientY - rect.top - rect.height / 2;

    const maxTranslate = 20;
    const newX = Math.max(Math.min(x / 10, maxTranslate), -maxTranslate);
    const newY = Math.max(Math.min(y / 10, maxTranslate), -maxTranslate);

    setTransform({ x: newX, y: newY });
  };

  const handleMouseLeave = () => {
    setIsHover(false);
    setTransform({ x: 0, y: 0 });
  };

  const handleMouseEnter = () => {
    setIsHover(true);
  };

  useEffect(() => {
    if (!isHover && textRef.current) {
      textRef.current.style.transition = "transform 0.3s ease-out";
    } else if (isHover && textRef.current) {
      textRef.current.style.transition = "";
    }
  }, [isHover]);

  return (
    <span
      ref={textRef}
      className={clsx("inline-block", className)}
      onMouseMove={handleMouseMove}
      onMouseEnter={handleMouseEnter}
      onMouseLeave={handleMouseLeave}
      style={{
        transform: `translate(${transform.x}px, ${transform.y}px)`,
      }}
    >
      {children}
    </span>
  );
};
