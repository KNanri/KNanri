export interface CareerCard {
  key: string;
  jaTitle: string;
  enTitle: string;
  jaDescription: string;
  enDescription: string;
}

export const careerCardsData: CareerCard[] = [
  {
    key: "producer",
    jaTitle: "プロデューサー",
    enTitle: "Producer",
    jaDescription:
      "&Jamでは、AIやバーチャルヒューマンを活用した最先端のプロジェクトを手掛けています。私たちは、バーチャルヒューマンをゼロからプロデュースし、企画段階から完成まで全面的にクリエイティブなサポートを行うことができるプロフェッショナルを求めています。クライアントのビジョンを具現化し、新しい価値観を創出するプロデューサーとして、バーチャルヒューマンの未来を共に切り拓きましょせんか？",
    enDescription:
      "&Jam is working on cutting-edge projects that utilize AI and virtual humans. We are looking for professionals who can produce virtual humans from scratch and provide full creative support from the planning stage to completion. Let's carve out the future of virtual humans together as a producer who embodies the client's vision and creates new values.",
  },
  {
    key: "designer",
    jaTitle: "デザイナー",
    enTitle: "Designer",
    jaDescription:
      "クライアントのビジョンを革新的なデザインで形にし、視覚的なインパクトを与えるデザイナーを求めています。あなたのクリエイティブな才能を活かし、画像合成やグラフィック制作を通じて、ユニークで魅力的なビジュアルを生み出す挑戦的なプロジェクトが待っています。デザインで未来を創り、感動を与える仕事に一緒に取り組みませんか？",
    enDescription:
      "We are looking for designers who bring our clients' visions to life with innovative designs that create visual impact. A challenging project awaits where you use your creative talents to create unique and captivating visuals through image compositing and graphic production. Would you like to create the future through design and work together on work that inspires people?",
  },
  {
    key: "ai-engineer",
    jaTitle: "AIエンジニア",
    enTitle: "AI Engineer",
    jaDescription:
      "私たちは、AIとクリエイティブな表現を融合させ、これまでにない新たな価値を生み出し、バーチャルヒューマンを通じた革新的な体験を提供しています。AIエンジニアとして、あなたの知識とスキルを活かし、バーチャルヒューマンを支える最先端のAI技術開発をリードしませんか？技術と創造力の限界に挑戦し、未来のデジタル体験を共に切り拓く機会がここにあります。",
    enDescription:
      "We fuse AI and creative expression to create unprecedented new value and provide innovative experiences through virtual humans. As an AI engineer, would you like to use your knowledge and skills to lead the development of cutting-edge AI technology that supports virtual humans? Here's your chance to push the limits of technology and creativity, and together carve out the digital experiences of the future.",
  },
  {
    key: "unreal-engine-unity-engineer",
    jaTitle: "Unreal Engine / Unity エンジニア",
    enTitle: "Unreal Engine / Unity",
    jaDescription:
      "私たちは、アートとテクノロジーを融合させ、これまでにない新しい価値を生み出すことを目指しています。UnrealエンジニアやUnityエンジニアとして、あなたのスキルを活かし、インタラクティブなデジタル体験やライブ配信を通じて、視覚的に圧倒的なプロジェクトを手掛けませんか？技術とクリエイティブの境界を超え、ビジュアル表現の限界に挑戦する機会がここにあります。",
    enDescription:
      "We aim to create unprecedented new value by fusing art and technology. As an Unreal or Unity engineer, use your skills to create visually stunning projects through interactive digital experiences and live streaming. Here is an opportunity to transcend the boundaries between technology and creativity and challenge the limits of visual expression.",
  },
  {
    key: "marketing-specialist",
    jaTitle: "マーケティングスペシャリスト",
    enTitle: "Marketing Specialist",
    jaDescription:
      "&Jamでは、バーチャルヒューマンやAI技術を活用した革新的なコンテンツを世界に発信しています。この魅力的なプロダクトをグローバルな市場に届け、新たなファンベースを一から築き上げるマーケティング担当者を募集しています。あなたのマーケティング戦略とクリエイティブな発想で、海外市場へのリーチを拡大し、&Jamのブランドを世界に広めてください。",
    enDescription:
      "&Jam delivers innovative content that utilizes virtual humans and AI technology to the world. We're looking for a marketer to bring this exciting product to a global market and build a new fan base from the ground up. Use your marketing strategies and creative ideas to expand your reach into overseas markets and spread the and Jam brand around the world.",
  },
  {
    key: "bizdev-sales",
    jaTitle: "ビジネス / 営業",
    enTitle: "BizDev / Sales",
    jaDescription:
      "バーチャルヒューマンやAI技術を活用した革新的なプロダクトを開発し、ビジネスの最前線で活躍するBizDev/Sales担当者を募集しています。新しいビジネスチャンスを見出し、クライアントとの関係を構築しながら、ビジネスを成長させるための中心的な役割を担っていただきます。あなたの営業力とビジネス開発スキルで、次なるステージへと導いてください。技術とクリエイティブの境界を超え、ビジュアル表現の限界に挑戦する機会がここにあります。",
    enDescription:
      "We are looking for BizDev/Sales personnel who will develop innovative products that utilize virtual humans and AI technology and will be active at the forefront of business. You will play a central role in growing the business, identifying new business opportunities and building relationships with clients. Take your sales and business development skills to the next stage.",
  },
  {
    key: "frontend-engineer",
    jaTitle: "フロントエンドエンジニア",
    enTitle: "Frontend Engineer",
    jaDescription:
      "私たちは、バーチャルヒューマンやAI技術を活用した最先端のプロダクト開発を行っています。ユーザー体験を向上させるインターフェースを設計・開発し、革新的なWebアプリケーションの実現に貢献できるフロントエンドエンジニアを募集しています。",
    enDescription:
      "We develop cutting-edge products that utilize virtual humans and AI technology. We are looking for a front-end engineer who can design and develop interfaces that improve the user experience and contribute to the realization of innovative web applications.",
  },
  {
    key: "backend-engineer",
    jaTitle: "バックエンドエンジニア",
    enTitle: "Backend Engineer",
    jaDescription:
      "私たちは、バーチャルヒューマンやAI技術を活用した次世代のサービス基盤を構築しています。データベース設計やAPI開発、スケーラブルなサーバーサイドの構築を担うバックエンドエンジニアを募集しています。",
    enDescription:
      "We are building a next-generation service platform that utilizes virtual humans and AI technology. We are looking for a backend engineer who will be responsible for database design, API development, and scalable server-side construction.",
  },
];
