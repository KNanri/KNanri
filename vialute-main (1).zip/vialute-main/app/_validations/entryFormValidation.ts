import { EntryContentState } from "@/_types/EntryContentTypes";
import errorMessage from "@/_validations/error.json";

const isValidMail = (email: string) => {
  const re =
    /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
  return re.test(String(email).toLowerCase());
};

export const entryFormValidation = (request: EntryContentState) => {
  const errors: { [key: string]: string } = {};

  if (!request.roleName) {
    errors.roleName = errorMessage.fieldValue.emptyRoleName;
  }
  if (!request.name) {
    errors.name = errorMessage.fieldValue.emptyName;
  }
  if (!request.mail) {
    errors.mail = errorMessage.fieldValue.emptyMail;
  } else if (!isValidMail(request.mail)) {
    errors.mail = errorMessage.fieldValue.invalidMail;
  }
  if (!request.ruby) {
    errors.ruby = errorMessage.fieldValue.emptyRuby;
  }
  if (!request.tel) {
    errors.tel = errorMessage.fieldValue.emptyTel;
  }

  const isValid = Object.keys(errors).length === 0;
  return { isValid, errors };
};
