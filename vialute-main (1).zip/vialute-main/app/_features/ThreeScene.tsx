"use client";

import React, { useRef, useEffect } from "react";
import {
  Canvas,
  useFrame,
  useLoader,
  useThree
} from "@react-three/fiber";
import * as THREE from "three";
import { useWindowSize } from "@/_hooks/useWindowSize"; 

function Box() {
  const mesh = useRef<THREE.Mesh>(null!);

  const imagePaths = [
    "/images/KV04.png",
    "/images/KV02.png",
    "/images/slide-blank.png",
    "/images/slide-blank.png",
    "/images/KV01.png",
    "/images/KV03.png",
  ];

  const textures = useLoader(THREE.TextureLoader, imagePaths);
  textures.forEach((texture) => {
    texture.minFilter = THREE.LinearFilter;
    texture.magFilter = THREE.LinearFilter;
    texture.colorSpace = THREE.SRGBColorSpace;
  });

  // const links = [
  //   "/2", // 4枚目
  //   "/2", // 2枚目
  //   "/", // 上
  //   "/", // 下
  //   "/1", // 1枚目
  //   "/1", // 3枚目
  // ];

  const materials = [];
  for (let i = 0; i < 6; i++) {
    const texture = textures[i % textures.length];
    materials.push(
      new THREE.MeshStandardMaterial({
        map: texture,
        metalness: 0,
        roughness: 1,
      })
    );
  }

  const geometry = new THREE.BoxGeometry(1, 1, 1);

  useFrame(() => {
    if (mesh.current) {
      mesh.current.rotation.y += 0.001;
    }
  });

  // const handleClick = (event: ThreeEvent<MouseEvent>) => {
  //   event.stopPropagation();
  //   const faceIndex = event.faceIndex;
  //   if (typeof faceIndex === "number") {
  //     const sideIndex = Math.floor(faceIndex / 2);
  //     const link = links[sideIndex % links.length];
  //     if (link) {
  //       window.location.href = link;
  //     }
  //   }
  // };

  return (
    <mesh
      ref={mesh}
      position={[0, 0, -0.3]}
      geometry={geometry}
      material={materials}
      // onClick={handleClick}
    ></mesh>
  );
}

function BackgroundPlane() {
  const mesh = useRef<THREE.Mesh>(null!);
  const texture = useLoader(THREE.TextureLoader, "/images/top_back.png");

  useFrame(({ mouse }) => {
    if (mesh.current) {
      mesh.current.rotation.x = mouse.y * 0.01;
      mesh.current.rotation.y = mouse.x * 0.03;
    }
  });

  return (
    <mesh ref={mesh} position={[0, 0, -6]}>
      <planeGeometry args={[25, 25*982/1767]} />
      <meshStandardMaterial map={texture}/>
    </mesh>
  );
}

// カメラ制御用のコンポーネント
const CameraController = () => {
  const { camera } = useThree();
  const windowSize = useWindowSize();

  useEffect(() => {
    // 例として、画面幅が768px未満の場合はカメラを近づけ、それ以上は離す
    if (windowSize.width < 768) {
      camera.position.set(0, 0, 2);
    } else {
      camera.position.set(0, 0, 1.5);
    }

    // カメラの更新を反映
    camera.updateProjectionMatrix();
  }, [windowSize, camera]);

  return null;
};

export const ThreeScene = () => {

  return (
    <Canvas
      style={{
        position: "absolute",
        top: 0,
        left: 0,
        width: "100%",
        height: "100%",
        background: "#000000",
      }}
      camera={{ position: [0, 0, 1.5], fov: 75 }}
    >
      <ambientLight intensity={1.5} />
      <pointLight position={[0, 0, 1]} intensity={0.3} />
      <BackgroundPlane />
      <Box />
      <CameraController />
    </Canvas>
  );
};
