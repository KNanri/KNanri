import clsx from "clsx";
import { AnimatedLinkButton } from "@/_components/animations/AnimatedLinkButton";

interface CardProps {
  cardKey: string;
  jaTitle: string;
  enTitle: string;
  jaDescription: string;
  enDescription: string;
}

export const Card = ({
  cardKey,
  jaTitle,
  enTitle,
  jaDescription,
  enDescription,
}: CardProps) => {
  return (
    <div
      className={clsx(
        "card-container",
        "clip-trapezoid",
        "flex",
        "w-full",
        "h-[calc((100vw-160px)*0.32)]",
        "max-h-[calc((1536px-160px)*0.32)]",
        "[&:not(:first-child)]:mt-[max(calc(-1*(100vw-160px)*0.32/2),calc(-1*(1536px-160px)*0.32/2))]",
        "px-[80px]",
        "py-[32px]",
        "transition-transform",
        "duration-500",
        "ease-in",
        "hover:-translate-y-[42.5%]",
        "bg-white",
        "shadow-inner",
        "text-main-black"
      )}
    >
      <div className={clsx("flex", "flex-col")}>
        <div className={clsx("flex", "justify-between")}>
          <div>
            <p className={clsx("text-[16px]", "text-gray")}>{jaTitle}</p>
            <p className={clsx("mt-[4px]", "text-[80px]", "text-stroke")}>
              {enTitle}
            </p>
          </div>
          <AnimatedLinkButton href={`/careers/${cardKey}`} text="more" />
        </div>
        <div
          className={clsx(
            "flex",
            "justify-between",
            "mt-[16px]",
            "leading-[2.0]",
            "text-[14px]"
          )}
        >
          <p className={clsx("mr-[80px]")}>{jaDescription}</p>
          <p className={clsx("text-gray")}>{enDescription}</p>
        </div>
      </div>
    </div>
  );
};
