"use client";

import clsx from "clsx";
import Image from "next/image";
import { useRouter } from "next/navigation";
import { AnimatedLinkButton } from "@/_components/animations/AnimatedLinkButton";
import { useSetRecoilState } from "recoil";
import { roleNameState } from "@/_stores/RoleNameStore";

interface JoinUsCardProps {
  roleName?: string;
}

export const JoinUsCard = ({ roleName }: JoinUsCardProps) => {
  const router = useRouter();
  const setRoleName = useSetRecoilState(roleNameState);

  const handleClick = () => {
    if (roleName) {
      setRoleName(roleName);
      router.push("/careers/entry");
    }
  };

  return (
    <div
      className={clsx(
        "flex",
        "flex-col",
        "justify-center",
        "items-center",
        "mt-[180px]",
        "mx-[-80px]",
        "px-[200px]",
        "py-[144px]",
        "bg-white"
      )}
    >
      <div className={clsx("flex", "items-center", "mr-[14px]")}>
        <Image
          className={clsx("mt-[-28px]", "mr-[-28px]", "w-[192px]")}
          src="/logo/andjam_logo_character_purple.png"
          alt="ロゴ"
          width={512}
          height={512}
          priority
        />
        <p className={clsx("text-[120px]", "text-stroke")}>OIN US</p>
      </div>
      <p className={clsx("mt-[32px]", "text-[16px]")}>
        一緒に未来を創り、感動を与える仕事に一緒に取り組みませんか？
      </p>
      <button onClick={handleClick}>
        <AnimatedLinkButton href="/careers/entry" text="entry" />
      </button>
    </div>
  );
};
