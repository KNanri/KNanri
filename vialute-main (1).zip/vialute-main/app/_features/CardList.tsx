import clsx from "clsx";
import Image from "next/image";
import { Card } from "@/_features/Card";
import { careerCardsData, CareerCard } from "@/_strings/careerCardsInfo";

interface CardListProps {
  isCharacter?: boolean;
}

export const CardList = ({ isCharacter }: CardListProps) => {
  return (
    <div
      className={clsx(
        "relative",
        "w-[100%]",
        "max-w-[calc(1536px-160px)]",
        "h-[calc(100vw-160px)*0.32]",
        "mx-auto",
        "mt-[240px]"
      )}
    >
      {isCharacter && (
        <Image
          className={clsx(
            "absolute",
            "top-[max(-12%,_-200px)]",
            "right-[-10%]",
            "w-[40vw]",
            "max-w-[calc((1536px)*0.4)]"
          )}
          src="/logo/andjam_logo_character_purple.png"
          alt="ロゴ"
          width={512}
          height={512}
          priority
        />
      )}
      {careerCardsData.map((card: CareerCard) => (
        <Card
          key={card.key}
          cardKey={card.key}
          jaTitle={card.jaTitle}
          enTitle={card.enTitle}
          jaDescription={card.jaDescription}
          enDescription={card.enDescription}
        />
      ))}
    </div>
  );
};
