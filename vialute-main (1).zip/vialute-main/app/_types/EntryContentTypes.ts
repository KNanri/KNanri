export type EntryContentState = {
  roleName: string | null;
  name: string;
  ruby: string;
  tel: string;
  mail: string;
  reason: string;
  portfolio: string;
};

export type EntryContentToSend = {
  roleName: string;
  name: string;
  ruby: string;
  tel: string;
  mail: string;
  reason: string;
  portfolio: string;
};
