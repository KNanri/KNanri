import { entryContentState } from "@/_states/entryContentState";

export const entryEmailContents = (info: typeof entryContentState) => {
  return `
${info.name}様

この度はご応募いただき、誠にありがとうございます。

下記の内容でご応募を承りました。
お送りいただいた内容を確認させていただき、1〜3営業日以内に担当者よりご連絡いたします。
しばらくお待ちくださいませ。

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

◆ご応募内容の確認

お名前：${info.name}
フリガナ：${info.ruby}
電話番号：${info.tel}
メールアドレス：${info.mail}
志望動機：${info.reason}
ポートフォリオURL：${info.portfolio}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

※本メールは自動送信されています。返信いただいても対応できませんので、ご了承ください。
`;
};
