import clsx from "clsx";
import Image from "next/image";
import { CharChangeAnimation } from "@/_components/animations/CharChangeAnimation";

export default function Projects() {
  return (
    <div
      className={clsx(
        "flex",
        "flex-col",
        "items-center",
        "pt-[120px]",
        "sm:pt-[300px]"
      )}
    >
      <div className={clsx("flex", "flex-col", "items-center", "font-[300]")}>
        <p
          className={clsx(
            "mt-[32px]",
            "sm:mt-0",
            "text-[32px]",
            "sm:text-[64px]",
            "text-center"
          )}
        >
          <CharChangeAnimation
            text="VIRTUAL HUMAN PRODUCTION"
            duration={1000}
          />
        </p>
        <Image
          className={clsx(
            "w-[236px]",
            "sm:w-[409px]",
            "h-auto",
            "my-[60px]",
            "sm:my-[44px]"
          )}
          src="/logo/andjam_logo_black.png"
          alt="&jam ロゴ"
          width={4096}
          height={2304}
          priority
        />
        <div
          className={clsx(
            "w-[320px]",
            "sm:w-[908px]",
            "leading-[1.65]",
            "text-[14px]",
            "sm:text-[20px]",
            "text-center"
          )}
        >
          <p>
            私たちは、世界初のバーチャルヒューマンプロダクションとして、ヒューマンライクなテクノロジーとクリエイティブを融合し、リアルで個性的なバーチャルヒューマンをプロデュースしています。
          </p>
          <br />
          <p>
            最新の3D技術とAIを駆使し、キャラクター設計からリアルタイム対話、SNSでのプロモーションまで一貫したプロデュース体制をご提供いたします。
            <br />
            広告、エンターテインメント、顧客対応など、多様な分野で活躍する彼らを通じて、人々の心を動かし可能性を拡張する新たな価値を創造します。
          </p>
        </div>
      </div>
      <div
        className={clsx(
          "flex",
          "flex-col",
          "gap-y-[16px]",
          "sm:gap-y-[24px]",
          "sm:w-[calc(100vw-160px)]",
          "max-w-[336px]",
          "sm:max-w-[1352px]",
          "my-[100px]",
          "sm:my-[160px]",
          "font-verdana",
          "text-[40px]",
          "sm:text-[100px]",
          "overflow-hidden"
        )}
      >
        <div
          className={clsx(
            "flex",
            "flex-col",
            "sm:flex-row",
            "justify-between",
            "gap-y-[16px]",
            "sm:gap-y-[0px]"
          )}
        >
          <p>WE</p>
          <p>VIRTYAL HUMAN</p>
        </div>
        <div
          className={clsx(
            "flex",
            "flex-col",
            "sm:flex-row",
            "justify-between",
            "gap-y-[16px]",
            "sm:gap-y-[0px]"
          )}
        >
          <p>＜& Jam＞</p>
          <p>AI AND</p>
        </div>
        <div
          className={clsx(
            "flex",
            "flex-col",
            "sm:flex-row",
            "justify-between",
            "gap-y-[16px]",
            "sm:gap-y-[0px]"
          )}
        >
          <p>CREATIVITY</p>
          <p>PARADIGM</p>
        </div>
        <div
          className={clsx(
            "flex",
            "flex-col",
            "sm:flex-row",
            "justify-between",
            "gap-y-[16px]",
            "sm:gap-y-[0px]"
          )}
        >
          <p>VALUE</p>
          <p>NEW ERA CREATE</p>
        </div>
      </div>
      <div
        className={clsx(
          "flex",
          "flex-col",
          "w-[100vw]",
          "h-auto",
          "px-0",
          "sm:pr-[80px]",
          "sm:pl-[140px]",
          "py-[100px]",
          "sm:py-[240px]",
          "bg-black",
          "overflow-hidden"
        )}
      >
        <div className={clsx("relative")}>
          <Image
            className={clsx("relative", "w-[320px]", "sm:w-[700px]", "z-[10]")}
            src="/images/Lio.png"
            alt="Lio"
            width={700}
            height={700}
            priority
          />
          <p
            className={clsx(
              "mt-[16px]",
              "ml-[16px]",
              "sm:ml-[-16px]",
              "font-[600]",
              "text-[100px]",
              "sm:text-[200px]",
              "text-white",
              "tracking-[.09em]"
            )}
          >
            Lio
          </p>
          <div
            className={clsx(
              "text-[64px]",
              "sm:text-[96px]",
              "text-white",
              "tracking-[.09em]"
            )}
          >
            <div
              className={clsx(
                "absolute",
                "top-[98px]",
                "sm:top-[365px]",
                "left-[-580px]",
                "flex",
                "gap-x-[35px]",
                "w-[100vw]",
                "whitespace-nowrap"
              )}
            >
              <p className={clsx("text-stroke-white")}>
                <span className={clsx("sm:text-[128px]")}>V</span>
                irtual <span className={clsx("sm:text-[128px]")}>H</span>uman
              </p>
              <p className={clsx("font-lemon", "text-purple")}>
                <span className={clsx("sm:text-[128px]")}>V</span>
                irtual <span className={clsx("sm:text-[128px]")}>H</span>uman
              </p>
              <p className={clsx("text-stroke-white")}>
                <span className={clsx("sm:text-[128px]")}>V</span>
                irtual <span className={clsx("sm:text-[128px]")}>H</span>uman
              </p>
            </div>
            <div
              className={clsx(
                "absolute",
                "top-[210px]",
                "sm:top-[552px]",
                "left-[-790px]",
                "flex",
                "gap-x-[35px]",
                "whitespace-nowrap"
              )}
            >
              <p className={clsx("text-stroke-white")}>
                <span className={clsx("sm:text-[128px]")}>V</span>
                irtual <span className={clsx("sm:text-[128px]")}>H</span>uman
              </p>
              <p className={clsx("text-stroke-white")}>
                <span className={clsx("sm:text-[128px]")}>V</span>
                irtual <span className={clsx("sm:text-[128px]")}>H</span>uman
              </p>
              <p className={clsx("font-lemon", "text-stroke-purple")}>
                <span className={clsx("sm:text-[128px]")}>V</span>
                irtual <span className={clsx("sm:text-[128px]")}>H</span>uman
              </p>
            </div>
          </div>
        </div>

        <div
          className={clsx("flex", "justify-end", "mt-[40px]", "sm:mt-[240px]")}
        >
          <div>
            <Image
              className={clsx(
                "relative",
                "w-[320px]",
                "sm:w-[700px]",
                "z-[10]"
              )}
              src="/images/KV04.png"
              alt="Hinata Sui"
              width={700}
              height={700}
              priority
            />
            <p
              className={clsx(
                "mt-[20px]",
                "mb-[4px]",
                "sm:my-[24px]",
                "text-[32px]",
                "sm:text-[40px]",
                "text-white",
                "tracking-[.09em]"
              )}
            >
              Hinata Sui
            </p>
            <p
              className={clsx(
                "ml-[-16px]",
                "font-[600]",
                "text-[100px]",
                "sm:text-[128px]",
                "text-white",
                "tracking-[.09em]"
              )}
            >
              日向 翠
            </p>
          </div>
        </div>

        <div className={clsx("relative", "mt-[40px]", "sm:mt-[360px]")}>
          <Image
            className={clsx("relative", "w-[320px]", "sm:w-[700px]", "z-[10]")}
            src="/images/coming-soon.png"
            alt="Coming Soon"
            width={700}
            height={700}
            priority
          />
          <div
            className={clsx(
              "text-[64px]",
              "sm:text-[128px]",
              "text-white",
              "tracking-[.09em]"
            )}
          >
            <div
              className={clsx(
                "absolute",
                "top-[60px]",
                "sm:top-[365px]",
                "left-[-500px]",
                "sm:left-[-820px]",
                "flex",
                "gap-x-[35px]",
                "w-[100vw]",
                "whitespace-nowrap"
              )}
            >
              <p className={clsx("text-stroke-white")}>Live Streaming</p>
              <p className={clsx("font-lemon", "text-purple")}>
                Live Streaming
              </p>
            </div>
            <div
              className={clsx(
                "absolute",
                "top-[171px]",
                "sm:top-[552px]",
                "left-[-200px]",
                "flex",
                "gap-x-[35px]",
                "whitespace-nowrap"
              )}
            >
              <p className={clsx("text-stroke-white")}>Live Streaming</p>
              <p className={clsx("font-lemon", "text-stroke-purple")}>
                Live Streaming
              </p>
            </div>
          </div>
        </div>
      </div>
      <div
        className={clsx(
          "pt-[100px]",
          "sm:pt-[260px]",
          "pl-[40px]",
          "sm:pl-[140px]",
          "overflow-hidden",
          "max-w-[100vw]"
        )}
      >
        <div className={clsx("mt-[48px]")}>
          <p
            className={clsx(
              "w-[234px]",
              "sm:w-[815px]",
              "font-[200]",
              "text-[36px]",
              "sm:text-[128px]",
              "text-black"
            )}
          >
            CREATIVE CONSULTING
          </p>
          <div className={clsx("flex", "flex-col", "sm:flex-row")}>
            <Image
              className={clsx(
                "w-[343px]",
                "sm:w-[670px]",
                "mt-[80px]",
                "sm:mt-[48px]"
              )}
              src="/images/creative-consulting.png"
              alt="Creative Consulting"
              width={670}
              height={715}
              priority
            />
            <p
              className={clsx(
                "w-[316px]",
                "sm:w-[640px]",
                "mt-[64px]",
                "sm:mt-[400px]",
                "leading-[2.25]",
                "sm:leading-[1.65]",
                "font-[200]",
                "text-[14px]",
                "sm:text-[20px]"
              )}
            >
              多彩なスキルや様々な領域で深い専門性を持つクリエイティブの専門家が、事業を生み出すプロセスにおいて、アイディアの発想から実現までを一貫してサポートします。
              <br />
              <br />
              ブランディングから制作まで、パートナーとして共に進み、クリエイティブな視点で価値を創造します。
            </p>
          </div>
        </div>
        <div className={clsx("mt-[100px]")}>
          <p
            className={clsx(
              "font-[200]",
              "text-[36px]",
              "sm:text-[128px]",
              "text-black"
            )}
          >
            EXPERTISES
          </p>
          <div
            className={clsx(
              "flex",
              "gap-x-[48px]",
              "max-w-[100vw]",
              "mt-[64px]",
              "overflow-hidden"
            )}
          >
            <div
              className={clsx(
                "flex",
                "flex-col",
                "gap-y-[120px]",
                "sm:gap-y-[100px]",
                "w-[780px]"
              )}
            >
              <div>
                <p
                  className={clsx(
                    "font-[600]",
                    "text-[64px]",
                    "sm:text-[96px]",
                    "text-purple"
                  )}
                >
                  Brand
                </p>
                <div
                  className={clsx(
                    "flex",
                    "flex-col",
                    "gap-y-[28px]",
                    "mt-[32px]"
                  )}
                >
                  <div
                    className={clsx("flex", "items-baseline", "text-[20px]")}
                  >
                    <span
                      className={clsx(
                        "block",
                        "w-[14px]",
                        "h-[8px]",
                        "mr-[16px]",
                        "ml-[4px]",
                        "bg-main-black"
                      )}
                    ></span>
                    <p>Branding</p>
                  </div>
                  <div
                    className={clsx("flex", "items-baseline", "text-[20px]")}
                  >
                    <span
                      className={clsx(
                        "block",
                        "w-[14px]",
                        "h-[8px]",
                        "mr-[16px]",
                        "ml-[4px]",
                        "bg-main-black"
                      )}
                    ></span>
                    <p>Creative direction</p>
                  </div>
                  <div
                    className={clsx("flex", "items-baseline", "text-[20px]")}
                  >
                    <span
                      className={clsx(
                        "block",
                        "w-[14px]",
                        "h-[8px]",
                        "mr-[16px]",
                        "ml-[4px]",
                        "bg-main-black"
                      )}
                    ></span>
                    <p>Art direction</p>
                  </div>
                  <div
                    className={clsx("flex", "items-baseline", "text-[20px]")}
                  >
                    <span
                      className={clsx(
                        "block",
                        "w-[14px]",
                        "h-[8px]",
                        "mr-[16px]",
                        "ml-[4px]",
                        "bg-main-black"
                      )}
                    ></span>
                    <p>Storytelling</p>
                  </div>
                </div>
              </div>
              <div className={clsx("sm:ml-[220px]")}>
                <p
                  className={clsx(
                    "font-[600]",
                    "text-[64px]",
                    "sm:text-[96px]",
                    "text-purple"
                  )}
                >
                  Business
                </p>
                <div
                  className={clsx(
                    "flex",
                    "flex-col",
                    "gap-y-[28px]",
                    "mt-[32px]"
                  )}
                >
                  <div
                    className={clsx("flex", "items-baseline", "text-[20px]")}
                  >
                    <span
                      className={clsx(
                        "block",
                        "w-[14px]",
                        "h-[8px]",
                        "mr-[16px]",
                        "ml-[4px]",
                        "bg-main-black"
                      )}
                    ></span>
                    <p>Business strategy</p>
                  </div>
                  <div
                    className={clsx("flex", "items-baseline", "text-[20px]")}
                  >
                    <span
                      className={clsx(
                        "block",
                        "w-[14px]",
                        "h-[8px]",
                        "mr-[16px]",
                        "ml-[4px]",
                        "bg-main-black"
                      )}
                    ></span>
                    <p>Communication strategy</p>
                  </div>
                </div>
              </div>
              <div>
                <p
                  className={clsx(
                    "font-[600]",
                    "text-[64px]",
                    "sm:text-[96px]",
                    "text-purple"
                  )}
                >
                  Design
                </p>
                <div
                  className={clsx(
                    "flex",
                    "flex-col",
                    "gap-y-[28px]",
                    "mt-[32px]"
                  )}
                >
                  <div
                    className={clsx("flex", "items-baseline", "text-[20px]")}
                  >
                    <span
                      className={clsx(
                        "block",
                        "w-[14px]",
                        "h-[8px]",
                        "mr-[16px]",
                        "ml-[4px]",
                        "bg-main-black"
                      )}
                    ></span>
                    <p>Service design</p>
                  </div>
                  <div
                    className={clsx("flex", "items-baseline", "text-[20px]")}
                  >
                    <span
                      className={clsx(
                        "block",
                        "w-[14px]",
                        "h-[8px]",
                        "mr-[16px]",
                        "ml-[4px]",
                        "bg-main-black"
                      )}
                    ></span>
                    <p>Visual design</p>
                  </div>
                  <div
                    className={clsx("flex", "items-baseline", "text-[20px]")}
                  >
                    <span
                      className={clsx(
                        "block",
                        "w-[14px]",
                        "h-[8px]",
                        "mr-[16px]",
                        "ml-[4px]",
                        "bg-main-black"
                      )}
                    ></span>
                    <p>UI/UX design</p>
                  </div>
                  <div
                    className={clsx("flex", "items-baseline", "text-[20px]")}
                  >
                    <span
                      className={clsx(
                        "block",
                        "w-[14px]",
                        "h-[8px]",
                        "mr-[16px]",
                        "ml-[4px]",
                        "bg-main-black"
                      )}
                    ></span>
                    <p>Space design</p>
                  </div>
                  <div
                    className={clsx("flex", "items-baseline", "text-[20px]")}
                  >
                    <span
                      className={clsx(
                        "block",
                        "w-[14px]",
                        "h-[8px]",
                        "mr-[16px]",
                        "ml-[4px]",
                        "bg-main-black"
                      )}
                    ></span>
                    <p>Interaction design</p>
                  </div>
                  <div
                    className={clsx("flex", "items-baseline", "text-[20px]")}
                  >
                    <span
                      className={clsx(
                        "block",
                        "w-[14px]",
                        "h-[8px]",
                        "mr-[16px]",
                        "ml-[4px]",
                        "bg-main-black"
                      )}
                    ></span>
                    <p>Exhibition design</p>
                  </div>
                </div>
              </div>
              <div className={clsx("sm:ml-[220px]")}>
                <p
                  className={clsx(
                    "font-[600]",
                    "text-[64px]",
                    "sm:text-[96px]",
                    "text-purple"
                  )}
                >
                  Digital
                </p>
                <div
                  className={clsx(
                    "flex",
                    "flex-col",
                    "gap-y-[28px]",
                    "mt-[32px]"
                  )}
                >
                  <div
                    className={clsx("flex", "items-baseline", "text-[20px]")}
                  >
                    <span
                      className={clsx(
                        "block",
                        "w-[14px]",
                        "h-[8px]",
                        "mr-[16px]",
                        "ml-[4px]",
                        "bg-main-black"
                      )}
                    ></span>
                    <p>Digital strategy</p>
                  </div>
                  <div
                    className={clsx("flex", "items-baseline", "text-[20px]")}
                  >
                    <span
                      className={clsx(
                        "block",
                        "w-[14px]",
                        "h-[8px]",
                        "mr-[16px]",
                        "ml-[4px]",
                        "bg-main-black"
                      )}
                    ></span>
                    <p>Data visualisation</p>
                  </div>
                  <div
                    className={clsx("flex", "items-baseline", "text-[20px]")}
                  >
                    <span
                      className={clsx(
                        "block",
                        "w-[14px]",
                        "h-[8px]",
                        "mr-[16px]",
                        "ml-[4px]",
                        "bg-main-black"
                      )}
                    ></span>
                    <p>Data construction</p>
                  </div>
                </div>
              </div>
            </div>
            <div>
              <p
                className={clsx(
                  "hidden",
                  "sm:inline",
                  "font-[200]",
                  "text-[96px]",
                  "text-medium-gray"
                )}
              >
                CREATIVE
                <br />
                PROFESSI
                <br />
                WITH DIVE
                <br />
                SKILLS
                <br />
                ANEXPERT
                <br />
                OSS VARI
                <br />
                FIELDS
                <br />
                PROCOMPREH
                <br />
                SUPPORT
                <br />
                THROUGHOUT
                <br />
                THE ENTIRE
                <br />
                PROCESS OF
                <br />
                BUSINESS
                <br />
                CREATION, FROM
                <br />
                IDEATION TO
                <br />
                IMPLEMENTATION.
                <br />
                AS YOUR
              </p>
            </div>
          </div>
          <div
            className={clsx(
              "flex",
              "flex-col",
              "items-center",
              "w-[313px]",
              "sm:w-auto",
              "mt-[140px]",
              "sm:mt-[20px]",
              "sm:ml-[-140px]",
              "text-center"
            )}
          >
            <p className={clsx("text-[14px]", "sm:text-[16px]")}>
              ご相談はこちらよりお気軽にご連絡ください。
              <br className={clsx("inline", "sm:hidden")} />
              担当者から返信を差し上げます。
            </p>
            <a
              href="mailto:hello@andjam.tokyo"
              className={clsx(
                "sm:w-[calc(100vw-500px)]",
                "mt-[60px]",
                "sm:mt-[80px]",
                "mx-[40px]",
                "sm:mx-auto",
                "p-[16px]",
                "sm:px-[80px]",
                "sm:py-[48px]",
                "border-main-black",
                "border-[1.5px]",
                "rounded-full",
                "font-[300]",
                "text-[32px]",
                "sm:text-[96px]",
                "text-white",
                "text-center",
                "bg-purple"
              )}
            >
              hello@andjam.tokyo
            </a>
          </div>
        </div>
      </div>
    </div>
  );
}
