import clsx from "clsx";
import { Metadata } from "next";

import { Header } from "@/_components/layouts/Header";
import { Footer } from "@/_components/layouts/Footer";

const MetaDataProps = {
  title: "PROJECTS",
  description: "株式会社&Jamのプロジェクト一覧",
  imageURL: `https://www.andjam.tokyo/ogp.png`,
  url: "andjam.tokyo/projects",
  type: "website" as const,
};

export const metadata: Metadata = {
  title: {
    default: "&Jam Inc.",
    template: `${MetaDataProps.title} | &Jam Inc.`,
  },
  description: MetaDataProps.description,
  twitter: {
    card: "summary_large_image",
    images: [
      {
        url: MetaDataProps.imageURL,
        width: 1200,
        height: 630,
        alt: MetaDataProps.title,
      },
    ],
  },
  openGraph: {
    title: MetaDataProps.title,
    description: MetaDataProps.description,
    url: MetaDataProps.url,
    siteName: "&amp;Jam Inc. Official HP",
    images: [
      {
        url: MetaDataProps.imageURL,
        width: 1200,
        height: 630,
        alt: MetaDataProps.title,
      },
    ],
    type: MetaDataProps.type,
    locale: "ja_JP",
  },
};

export default function ProjectsLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <>
      <Header
        textColor="text-main-black"
        logoSrc="/logo/andjam_logo_black.png"
      />
      <div
        className={clsx(
          "px-0",
          "sm:px-[80px]",
          "pb-[220px]",
          "bg-background",
          "text-main-black"
        )}
      >
        {children}
      </div>
      <Footer />
    </>
  );
}
