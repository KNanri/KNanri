import clsx from "clsx";
import { Metadata } from "next";
import "@/_common/styles/globals.css";
import "ress";
import RecoilProviders from "@/_providers/RecoilProviders";
import { MenuProvider } from "@/_contexts/MenuContext";
import { MouseFollower } from "@/_components/animations/MouseFollower";

const MetaDataProps = {
  title: "HOME",
  description:
    "私たちは革新的なヒューマンライクなテクノロジーで人々の可能性を拡張し、クリエイティブスキルやクリエイティブコンサルティングによって様々な顧客の新規事業から、既存の事業まで幅広く伴走しサポートします。",
  imageURL: `https://www.andjam.tokyo/ogp.png`,
  url: "andjam.tokyo",
  type: "website" as const,
};

export const metadata: Metadata = {
  title: {
    default: "&Jam Inc.",
    template: `${MetaDataProps.title} | &Jam Inc.`,
  },
  description: MetaDataProps.description,
  twitter: {
    card: "summary_large_image",
    images: [
      {
        url: MetaDataProps.imageURL,
        width: 1200,
        height: 630,
        alt: MetaDataProps.title,
      },
    ],
  },
  openGraph: {
    title: MetaDataProps.title,
    description: MetaDataProps.description,
    url: MetaDataProps.url,
    siteName: "&Jam Inc. Official HP",
    images: [
      {
        url: MetaDataProps.imageURL,
        width: 1200,
        height: 630,
        alt: MetaDataProps.title,
      },
    ],
    type: MetaDataProps.type,
    locale: "ja_JP",
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="ja">
      <head></head>
      <body className={clsx("w-[100%]", "leading-[1.15]", "font-sans")}>
        <RecoilProviders>
          <MenuProvider>
            {children}
            <MouseFollower />
          </MenuProvider>
        </RecoilProviders>
      </body>
    </html>
  );
}
