import { ThreeScene } from "@/_features/ThreeScene";
import { Header } from "@/_components/layouts/Header";
import { TopFooter } from "@/_components/layouts/TopFooter";

export default function Home() {
  return (
    <>
      <Header textColor="text-white" logoSrc="/logo/andjam_logo_white.png" />
      <div
        style={{
          position: "fixed",
          top: 0,
          left: 0,
          width: "100%",
          height: "100%",
          zIndex: -1,
        }}
      >
        <ThreeScene />
        <TopFooter />
      </div>
    </>
  );
}
