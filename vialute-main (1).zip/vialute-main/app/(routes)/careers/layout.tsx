import clsx from "clsx";
import { Metadata } from "next";

import { Header } from "@/_components/layouts/Header";
import { Footer } from "@/_components/layouts/Footer";

const MetaDataProps = {
  title: "CAREERS",
  description:
    "キャリア、リクルートページです。当社プロダクション所属のバーチャルヒューマンをプロデュースするプロデューサー。プロダクションの世界観を作り出し、クライアントのビジョンを創り出し伴走するデザイナー。バーチャルヒューマンの新たな可能性を拡張するAIエンジニア。Vtuberの根幹となるシステムを構築し、革新的なデジタルアートを生み出すUnreal EngineエンジニアとUnityエンジニア。＆Jamが手掛けるバーチャルヒューマンとデジタルアートをグローバルな市場に届け、新たなファンベースを一から築き上げるマーケティングスペシャリスト。新たなビジネスチャンスを作り出し、クライアントとの関係を構築しながらビジネスを成長させる中心的な営業。クライアントのビジョンを正確に構築できるフロントエンドエンジニア。バーチャルヒューマンやデジタルアート、次世代のサービス基盤の構築を担うバックエンドエンジニア。",
  imageURL: `https://www.andjam.tokyo/ogp.png`,
  url: "andjam.tokyo/careers",
  type: "website" as const,
};

export const metadata: Metadata = {
  title: {
    default: "&Jam Inc.",
    template: `${MetaDataProps.title} | &Jam Inc.`,
  },
  description: MetaDataProps.description,
  twitter: {
    card: "summary_large_image",
    images: [
      {
        url: MetaDataProps.imageURL,
        width: 1200,
        height: 630,
        alt: MetaDataProps.title,
      },
    ],
  },
  openGraph: {
    title: MetaDataProps.title,
    description: MetaDataProps.description,
    url: MetaDataProps.url,
    siteName: "&Jam Inc. Official HP",
    images: [
      {
        url: MetaDataProps.imageURL,
        width: 1200,
        height: 630,
        alt: MetaDataProps.title,
      },
    ],
    type: MetaDataProps.type,
    locale: "ja_JP",
  },
};

export default function CareersLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <>
      <Header
        textColor="text-main-black"
        logoSrc="/logo/andjam_logo_black.png"
      />
      <div
        className={clsx(
          "px-[80px]",
          "pb-[220px]",
          "bg-background",
          "overflow-hidden",
          "text-main-black"
        )}
      >
        {children}
      </div>
      <Footer />
    </>
  );
}
