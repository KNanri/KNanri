"use client";

import clsx from "clsx";
import Link from "next/link";
import { useParams } from "next/navigation";
import { useEffect, useState } from "react";
import { Title } from "@/_components/elements/Title";
import { JoinUsCard } from "@/_features/JoinUsCard";
import { careersData, Role, Section } from "@/_strings/careerDetailsInfo";

export default function CareersName() {
  const params = useParams();
  const name = Array.isArray(params.name) ? params.name[0] : params.name;
  const [role, setRole] = useState<Role | undefined>(undefined);

  useEffect(() => {
    const foundRole = careersData.roles.find((r) => r.key === name);
    setRole(foundRole);
  }, [name]);

  if (!role) {
    return (
      <div>
        <Title enTitle="Careers" className={ clsx("mt-[200px]")} />
        <div className={clsx("mt-[80px]", "text-center", "text-gray")}>
          <p>該当する役職が見つかりません。</p>
          <Link
            href="/careers"
            className={clsx(
              "mt-[16px]",
              "inline-block",
              "text-purple",
              "underline"
            )}
          >
            Careers一覧に戻る
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div>
      <Title enTitle="Careers" className={clsx("mt-[200px]")} />
      <div className={clsx("flex", "mt-[48px]", "ml-[20px]")}>
        <div
          className={clsx(
            "flex",
            "flex-col",
            "gap-y-[48px]",
            "w-[320px]",
            "mt-[32px]",
            "mr-[64px]"
          )}
        >
          {careersData.roles.map((roleItem: Role) => (
            <Link
              key={roleItem.key}
              href={`/careers/${roleItem.key}`}
              className={clsx(
                "flex",
                "items-baseline",
                "text-[20px]",
                roleItem.key === name ? "text-main-black" : "text-gray",
                "hover:text-main-black"
              )}
            >
              {roleItem.key === name ? (
                <>
                  <span
                    className={clsx(
                      "block",
                      "w-[14px]",
                      "h-[8px]",
                      "mr-[16px]",
                      "bg-main-black"
                    )}
                  ></span>
                  <p
                    className={clsx(
                      "line-through",
                      "decoration-[1px]",
                      "decoration-purple"
                    )}
                  >
                    {roleItem.english}
                  </p>
                </>
              ) : (
                <p>{roleItem.english}</p>
              )}
            </Link>
          ))}
        </div>
        <div>
          <div
            className={clsx(
              "w-[956px]",
              "pl-[28px]",
              "pb-[12px]",
              "border-b-[1px]",
              "border-gray"
            )}
          >
            <p className={clsx("text-[14px]", "text-gray")}>{role.japanese}</p>
            <p className={clsx("mt-[4px]", "text-[32px]")}>{role.english}</p>
          </div>
          <div>
            {role.sections.map((section: Section, sectionIndex: number) => (
              <div
                key={sectionIndex}
                className={clsx(
                  "flex",
                  "items-center",
                  "py-[60px]",
                  "border-b-[1px]",
                  "border-light-gray",
                  "text-[14px]"
                )}
              >
                <p className={clsx("w-[192px]", "px-[28px]", "text-gray")}>
                  {section.titleJapanese}
                </p>
                <p className={clsx("leading-[1.75]")}>
                  {section.content.map((item, idx) => (
                    <span key={idx}>
                      ・{item}
                      <br />
                    </span>
                  ))}
                </p>
              </div>
            ))}
          </div>
        </div>
      </div>
      <JoinUsCard roleName={role.english} />
    </div>
  );
}
