import clsx from "clsx";

export default function EntryCompletion() {
  return (
    <div className={clsx("flex", "items-center", "flex-col")}>
      <div className={clsx("mt-[48px]", "max-w-[780px]")}>
        <p className={clsx("text-[48px]")}>ご応募ありがとうございました。</p>
        <p className={clsx("mt-[48px]", "leading-[2.0]", "text-[24px]")}>
          お送りいただいた内容を確認させていただき、1〜3営業日以内に担当者よりご連絡いたします。
          <br />
          しばらくお待ちくださいませ。
          <br />
          <br />
          また、何かご不明点がございましたら、お気軽に以下のメールアドレスまでお問い合わせください。
          <br />
          お問い合わせ先： recruit@andjam.tokyo
          <br />
          <br />
          ご応募いただき、誠にありがとうございます。
          <br />
        </p>
      </div>
    </div>
  );
}
