import clsx from "clsx";
import { Title } from "@/_components/elements/Title";

export default function EntryLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <>
      <div className={clsx("relative", "mt-[200px]")}>
        <Title
          enTitle="Entry"
          jaTitle="採用応募"
          className={clsx("absolute")}
        />
        {children}
      </div>
    </>
  );
}
