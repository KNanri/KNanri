"use client";

import clsx from "clsx";
import { useRecoilState } from "recoil";
import Link from "next/link";
import Image from "next/image";
import { useRouter } from "next/navigation";
import { useState, Suspense } from "react";
import { sendToSlack } from "@/_services/slackServices";
// import { sendEmailWithSendGrid } from "@/_services/sendgridServices";
// import { entryEmailContents } from "@/_services/emailTemplates/entry";
import { Input } from "@/_components/elements/Input";
import { Textarea } from "@/_components/elements/Textarea";
import { Tag } from "@/_components/elements/Tag";
import { CardList } from "@/_features/CardList";
import { entryContentState } from "@/_states/entryContentState";
import { roleNameState } from "@/_stores/RoleNameStore";
import {
  EntryContentState,
  EntryContentToSend,
} from "@/_types/EntryContentTypes";
import { entryFormValidation } from "@/_validations/entryFormValidation";

const EntryContent: React.FC = () => {
  const router = useRouter();
  const [, setLoading] = useState(false);
  const [roleName, setRoleName] = useRecoilState(roleNameState);
  const [entryContent, setEntryContent] = useState<EntryContentState>({
    ...entryContentState,
    roleName: roleName,
  });
  const [isAgree, setIsAgree] = useState(false);
  const [entryFormErrors, setEntryFormErrors] = useState<{
    [key: string]: string;
  }>({});

  const RoleNameLists = [
    "Producer",
    "Designer",
    "AI Engineer",
    "Unreal Engine / Unity Engineer",
    "Marketing Specialist",
    "BizDev / Sales",
    "Frontend Engineer",
    "Backend Engineer",
  ];

  const toggleAgree = () => {
    setIsAgree((prev) => {
      const newAgree = !prev;
      if (newAgree) {
        setEntryFormErrors((prevErrors) => {
          const updatedErrors = { ...prevErrors };
          delete updatedErrors.agree;
          return updatedErrors;
        });
      }
      return newAgree;
    });
  };

  const handleTagClick = (selectedRole: string) => {
    setRoleName(selectedRole);
    setEntryContent((prev) => ({
      ...prev,
      roleName: selectedRole,
    }));
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setEntryContent({ ...entryContent, [name]: value });
  };

  const handleTextAreaChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setEntryContent({ ...entryContent, [name]: value });
  };

  const handleSubmit = async (e: React.MouseEvent<HTMLButtonElement>) => {
    e.preventDefault();

    const { isValid, errors } = entryFormValidation(entryContent);
    const newErrors: { [key: string]: string } = { ...errors };

    if (!isAgree) {
      newErrors.agree = "個人情報の取り扱いに同意してください";
    }

    setEntryFormErrors(newErrors);

    if (!isValid || !isAgree) {
      return;
    }

    setLoading(true);
    try {
      if (!entryContent.roleName) {
        throw new Error("roleName is null");
      }

      const sendContent: EntryContentToSend = {
        ...entryContent,
        roleName: entryContent.roleName,
      };

      const slackResult = await sendToSlack(sendContent);
      if (slackResult.status !== 200) throw new Error(slackResult.message);

      // const emailBody = entryEmailContents(entryContent);
      // const emailResult = await sendEmailWithSendGrid(
      //   entryContent.mail,
      //   "【株式会社 &Jam】ご応募ありがとうございます。",
      //   emailBody
      // );
      // if (emailResult.status !== 200) throw new Error(emailResult.message);

      setRoleName(null);
      setEntryContent({ ...entryContentState, roleName: null });
      setLoading(false);
      router.push("/careers/entry/completion");
    } catch (error) {
      alert(
        "応募内容の送信に失敗しました。\nお手数ですが、もう一度お試しください。"
      );
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className={clsx("flex", "items-center", "flex-col")}>
      <div className={clsx("flex", "flex-col")}>
        <div className={clsx("mt-[48px]", "mb-[32px]")}>
          <p className={clsx("text-[14px]", "text-gray")}>応募職種</p>
          <p className={clsx("mt-[4px]", "text-[24px]")}>Job opening type</p>
          <div
            className={clsx(
              "flex",
              "flex-wrap",
              "mt-[8px]",
              "max-w-[780px]",
              "break-words"
            )}
          >
            {RoleNameLists.map((name) => (
              <Tag
                key={name}
                name={name}
                selected={roleName === name}
                onClick={() => handleTagClick(name)}
              />
            ))}
          </div>
        </div>
        <Input
          name="name"
          jaLabel="氏名"
          enLabel="Name"
          placeholder="フルネーム"
          value={entryContent.name}
          onChange={handleInputChange}
          errorMessage={entryFormErrors.name}
          required
        />
        <Input
          name="ruby"
          jaLabel="フリガナ"
          enLabel="Ruby"
          placeholder="セイ メイ"
          value={entryContent.ruby}
          onChange={handleInputChange}
          errorMessage={entryFormErrors.ruby}
          required
        />
        <Input
          name="tel"
          jaLabel="電話番号"
          enLabel="TEL"
          placeholder="数字で記入してください"
          value={entryContent.tel}
          onChange={handleInputChange}
          errorMessage={entryFormErrors.tel}
          required
        />
        <Input
          name="mail"
          jaLabel="メールアドレス"
          enLabel="Mail"
          placeholder="メールアドレスを入力してください"
          value={entryContent.mail}
          onChange={handleInputChange}
          errorMessage={entryFormErrors.mail}
          required
        />
        <Textarea
          name="reason"
          jaLabel="志望動機"
          enLabel="Reason for applying"
          placeholder="志望動機を入力してください"
          value={entryContent.reason}
          onChange={handleTextAreaChange}
          errorMessage={entryFormErrors.reason}
        />
        <Input
          name="portfolio"
          jaLabel="ポートフォリオURL"
          enLabel="Portfolio’s URL"
          placeholder="https://"
          value={entryContent.portfolio}
          onChange={handleInputChange}
          errorMessage={entryFormErrors.portfolio}
        />
        <div className={clsx("flex", "flex-col")}>
          <div
            className={clsx(
              "flex",
              "justify-center",
              "items-center",
              "mt-[72px]"
            )}
          >
            <Image
              className={clsx("w-[22px]", "mr-[16px]")}
              src={
                isAgree
                  ? "/icons/checkbox_circle_purple.svg"
                  : "/icons/checkbox_circle_white.svg"
              }
              alt="チェックボックス"
              width={22}
              height={22}
              onClick={toggleAgree}
            />
            <div className={clsx("flex")}>
              <Link
                href="/careers/entry/agree-details"
                rel="noopener noreferrer"
                target="_blank"
              >
                <span
                  className={clsx("font-[600]", "text-purple", "underline")}
                >
                  個人情報の取り扱い
                </span>
              </Link>
              <p>&nbsp;について、同意の上応募します。</p>
            </div>
          </div>
          {entryFormErrors.agree && (
            <p className={clsx("mt-[32px]", "text-purple", "text-center")}>
              {entryFormErrors.agree}
            </p>
          )}
        </div>
        <button
          onClick={handleSubmit}
          className={clsx(
            "mt-[120px]",
            "py-[20px]",
            "rounded-full",
            "text-white",
            "bg-purple"
          )}
        >
          apply
        </button>
      </div>
      <CardList isCharacter={false} />
    </div>
  );
};

export default function Entry() {
  return (
    <Suspense fallback={<div>Loading...</div>}>
      <EntryContent />
    </Suspense>
  );
}
