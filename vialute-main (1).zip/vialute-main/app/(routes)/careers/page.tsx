import clsx from "clsx";
import { CardList } from "@/_features/CardList";
import { JoinUsCard } from "@/_features/JoinUsCard";

export default function Careers() {
  return (
    <div className={clsx("pt-[320px]")}>
      <CardList isCharacter={true} />
      <JoinUsCard />
    </div>
  );
}
