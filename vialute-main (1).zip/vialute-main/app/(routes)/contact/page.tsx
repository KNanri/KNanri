import clsx from "clsx";
import { CharChangeAnimation } from "@/_components/animations/CharChangeAnimation";

export default function Contact() {
  return (
    <div
      className={clsx(
        "flex",
        "flex-col",
        "items-center",
        "pt-[120px]",
        "sm:pt-[300px]"
      )}
    >
      <div
        className={clsx(
          "flex",
          "flex-col",
          "xl:flex-row",
          "items-center",
          "text-[24px]",
          "sm:text-[36px]"
        )}
      >
        <CharChangeAnimation text="PLEASE CONTACT US" duration={1000} />
        <p className={clsx("hidden", "sm:inline")}>&nbsp;</p>
        <CharChangeAnimation text="FROM HERE." duration={1000} />
      </div>
      <div
        className={clsx(
          "flex",
          "flex-col",
          "xl:flex-row",
          "items-center",
          "text-[24px]",
          "sm:text-[36px]"
        )}
      >
        <CharChangeAnimation text="A REPRESENTATIVE" duration={1000} />
        <p className={clsx("hidden", "sm:inline")}>&nbsp;</p>
        <CharChangeAnimation text="WILL CONTACT YOU SHORTLY." duration={1000} />
      </div>
      <p
        className={clsx(
          "mt-[48px]",
          "xl:mt-[60px]",
          "mx-[40px]",
          "text-[14px]",
          "sm:text-[16px]"
        )}
      >
        &Jamへの新規プロジェクトや取材・メディアへの掲載などのご相談はこちらよりお気軽にご連絡ください。担当者から返信を差し上げます。
      </p>
      <a
        href="mailto:hello@andjam.tokyo"
        className={clsx(
          "w-[calc(100vw-80px)]",
          "sm:w-auto",
          "mt-[100px]",
          "sm:mt-[40px]",
          "mx-[40px]",
          "p-[16px]",
          "sm:px-[80px]",
          "sm:py-[48px]",
          "border-main-black",
          "border-[1.5px]",
          "rounded-full",
          "font-[300]",
          "text-[32px]",
          "sm:text-[96px]",
          "text-white",
          "text-center",
          "bg-purple"
        )}
      >
        hello@andjam.tokyo
      </a>
    </div>
  );
}
