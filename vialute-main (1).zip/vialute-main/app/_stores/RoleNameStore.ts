import { atom } from "recoil";

export const roleNameState = atom<string | null>({
  key: "roleNameState",
  default: null,
});
