"use client";

import { RecoilRoot } from "recoil";

export default function RecoilProviders({ children }: { children: React.ReactNode }) {
  return <RecoilRoot>{children}</RecoilRoot>;
}
