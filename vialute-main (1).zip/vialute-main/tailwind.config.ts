import type { Config } from "tailwindcss";
import plugin from "tailwindcss/plugin";

const config: Config = {
  content: ["./app/**/*.{js,ts,jsx,tsx}"],
  theme: {
    extend: {
      fontFamily: {
        sans: ["Helvetica", "Arial", "sans-serif"],
        verdana: ["Verdana", "Arial", "sans-serif"],
        gillSans: ["'Gill Sans'", "Helvetica", "Arial", "sans-serif"],
        alexandria: ["'Alexandria'", "sans-serif"],
        lemon: ["'Lemon'", "sans-serif"],
      },
      colors: {
        "main-black": "#1A1A1A",
        black: "#000000",
        white: "#FFFFFF",
        gray: "#928B8A",
        "medium-gray": "#E9E9E9",
        "light-gray": "#D4D4D4",
        red: "#B12704",
        pink: "#FF1493",
        purple: "#BE00FF",
        background: "#F6F6F6",
      },
      clipPath: {
        trapezoid: "polygon(0% 0%, 100% 0%, 97.5% 100%, 2.5% 100%)",
      },
      boxShadow: {
        box: "0px 0px 60px 20px rgba(0, 0, 0, 0.05)",
      },
      keyframes: {
        poyoyon: {
          "0%": {
            transform: "translateX(140px)",
            opacity: "0",
          },
          "50%": {
            transform: "translateX(0)",
            opacity: "1",
          },
          "65%": {
            transform: "translateX(30px)",
          },
          "100%": {
            transform: "translateX(0)",
            opacity: "1",
          },
        },
      },
      animation: {
        poyoyon: "poyoyon 0.5s cubic-bezier(0.12, 0, 0.39, 0) 1 forwards",
      },
    },
  },
  plugins: [
    plugin(function ({ addUtilities }) {
      const newUtilities = {
        ".clip-trapezoid": {
          "clip-path": "polygon(0% 0%, 100% 0%, 97.5% 100%, 2.5% 100%)",
        },
      };
      addUtilities(newUtilities);
    }),
  ],
};

export default config;
